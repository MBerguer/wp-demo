<style>
    ul.inline li {float: left; display: inline; padding: 0; margin: 0 10px 0 0; }
    ul.news {}
    ul.news li.post {background-color: #f1f1f1; border: solid 2px #ddd; padding: 15px;}
    ul.news h5 {font-size: 18px; }
    div.cleaner {clear: left; }
    div#features li {float: left; display: inline; margin: 0 20px 15px 0; }
    div#features li img {margin: 0 10px 5px 0; }        
</style>
<div class="wrap">
    <h2>More from WPZOOM</h2>
     <div class="cleaner">&nbsp;</div>
    
    <iframe src="http://www.wpzoom.com/frame/" width="100%" height="1790"></iframe>
</div><!-- end .wrap -->
