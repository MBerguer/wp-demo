<?php return array(
/**
 * Theme configuration goes there
 */
    'name'    => 'Petit',   					 // theme name
    'styled'  => false,              			 // true if current theme supports styling
    'scripts' => array("dropdown", "custom")     // javascripts theme uses
);