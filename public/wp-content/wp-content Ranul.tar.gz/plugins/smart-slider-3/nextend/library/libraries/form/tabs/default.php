<?php
N2Loader::import('libraries.form.tab');

class N2TabDefault extends N2Tab
{

}