<?php
/* @var $this N2Layout */
?>
<div id="<?php echo $lightboxId; ?>" class="n2 n2-lightbox-container">
    <div class="n2-lightbox n2-border-radius">

        <div class="n2-table n2-table-fixed n2-content">
            <div class="n2-tr">
                <div class="n2-td n2-sidebar n2-sidebar-base-bg n2-border-radius-tl n2-border-radius-bl">
                    <div class="n2-blue-logo-bg n2-logo n2-border-radius-tl n2-lightbox-heading n2-h2">
                        <?php
                        echo $logo;
                        ?>
                    </div>
                    <?php
                    $this->renderFragmentBlock('nextend_sidebar');
                    ?>
                </div>

                <div class="n2-td n2-content-base-bg">
                    <!-- Begin Content -->
                    <?php
                    $this->renderFragmentBlock('nextend_content_top_bar');
                    ?>
                    <div class="n2-content-area n2-border-radius-br">
                        <?php
                        $this->renderFragmentBlock('nextend_content');
                        ?>
                    </div>
                    <!-- End Content -->
                </div>
            </div>
        </div>
    </div>
</div>