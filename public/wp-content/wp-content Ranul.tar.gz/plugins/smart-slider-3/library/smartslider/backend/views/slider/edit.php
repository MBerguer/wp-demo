<?php
/**
 * @var $_class N2SmartsliderBackendSliderView
 */
$title = $slider['title'];

include dirname(__FILE__) . '/_slider_edit.php';
